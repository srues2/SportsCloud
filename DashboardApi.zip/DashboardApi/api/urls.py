from django.contrib import admin
from django.urls import path
from rest_framework import routers
from django.conf.urls import include
from .views import ActivityViewSet, AssessmentViewSet, UserViewSet

router = routers.DefaultRouter()
router.register('users', UserViewSet)
router.register('activities', ActivityViewSet)
router.register('assessments', AssessmentViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
