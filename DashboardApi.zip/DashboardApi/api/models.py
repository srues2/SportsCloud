from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator, MinValueValidator

class Activity(models.Model):
    title = models.CharField(max_length=32)
    description = models.TextField(max_length=360)
    
    def no_of_assessments(self):
        assessments = Assessment.objects.filter(activity=self)
        return len(assessments)

    def avg_rating_activity(self):
        sum = 0
        assessments = Assessment.objects.filter(activity=self)
        for assessment in assessments:
            sum += assessment.rating
        if(len(assessments) > 0):
            return sum / len(assessments)
        else:
            return 0

class Assessment(models.Model):
    activity = models.ForeignKey(Activity, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    timeActivity = models.IntegerField()
    ratingTrainer = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    reason1Activity = models.BooleanField(null=True)
    reason2Activity = models.BooleanField(null=True)
    reason3Activity = models.BooleanField(null=True)
    reason4Activity = models.BooleanField(null=True)
    reason5Activity = models.BooleanField(null=True)
    reason6Activity = models.BooleanField(null=True)

    class Meta:
        unique_together = (('user', 'activity'),)
        index_together = (('user', 'activity'),)

