from django.contrib import admin
from .models import Activity, Assessment

# Register models.
admin.site.register(Activity)
admin.site.register(Assessment)

