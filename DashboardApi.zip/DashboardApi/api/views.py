from django.shortcuts import render
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import Activity, Assessment
from django.contrib.auth.models import User
from .serializers import ActivitySerializer, AssessmentSerializer, UserSerializer
from rest_framework.authentication import  TokenAuthentication
from rest_framework.permissions import IsAuthenticated

# Create views here.
class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

class ActivityViewSet(viewsets.ModelViewSet):
    queryset = Activity.objects.all()
    serializer_class = ActivitySerializer
    authentication_classes = (TokenAuthentication,)
    permission_classes = (IsAuthenticated,)

    @action(detail=True, methods=['POST'])
    def rate_activity(self, request, pk=None):
        if 'rating' in request.data:

            activity = Activity.objects.get(id=pk)
            rating = request.data['rating']
            user = request.user

            try:
               assessment = Assessment.objects.get(user=user.id, activity=activity.id)
               assessment.rating = rating
               assessment.save()
               serializer = AssessmentSerializer(assessment, many=False);
               response = {'message': 'Rating updated', 'result': serializer.data}
               return Response(response, status=status.HTTP_200_OK)
            except:
                assessment = Assessment.objects.create(user=user, activity=activity, rating=rating)
                serializer = AssessmentSerializer(assessment, many=False);
                response = {'message': 'Rating created', 'result': serializer.data}
                return Response(response, status=status.HTTP_200_OK)

        else:
            response = {'message': 'You need to provide rating'}
            return Response(response, status=status.HTTP_400_BAD_REQUEST)

class AssessmentViewSet(viewsets.ModelViewSet):
    authentication_classes = (TokenAuthentication,)
    queryset = Assessment.objects.all()
    serializer_class = AssessmentSerializer
    permission_classes = (IsAuthenticated,)

    def update(self, request, *args, **kwargs):
        response = {'message': 'You cant update assessment like that'}
        return Response(response, status=status.HTTP_400_BAD_REQUEST)

